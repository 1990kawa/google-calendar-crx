var constants = {};

constants.CALENDAR_UI_URL = 'https://calendar.google.com/calendar/';
constants.EVENT_STATUS_DECLINED = 'declined';
constants.INFO_BAR_DISMISS_TIMEOUT_MS = 5000;
constants.CALENDARS_STORAGE_KEY = 'calendars';
