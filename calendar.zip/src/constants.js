var constants = {}

constants.EVENT_STATUS_DECLINED = 'declined'
constants.EVENT_STATUS_ACCEPTED = 'accepted'
constants.EVENT_STATUS_TENTATIVE = 'tentative'
constants.EVENT_STATUS_NEED_ACTION = 'needAction'
constants.INFO_BAR_DISMISS_TIMEOUT_MS = 5000
constants.CALENDARS_STORAGE_KEY = 'calendars'
